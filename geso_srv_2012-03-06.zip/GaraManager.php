<?php

require_once("dblib.php");
require_once("clublib.php");

class GaraManager {
    function lista () {
        return connetti_query(
			"
				select 
					g.ID as ID,
					g.NOME as NOME, 
					g.LOCALITA as LOCALITA,
				    g.CAMPIONATO as CAMPIONATO,
					DATE_FORMAT(g.DATA, '%d/%m/%Y') as DATA
				from 
					gara g
				group by g.NOME, g.LOCALITA, g.DATA
			");
    }

	function get ($idGara) {
        return connetti_query(
			"
				select 
					g.ID as ID,
					g.NOME as NOME, 
					g.LOCALITA as LOCALITA,
				    g.CAMPIONATO as CAMPIONATO,
					DATE_FORMAT(g.DATA, '%d/%m/%Y') as DATA
				from 
					gara g
				where g.ID = '".$idGara."'
				group by g.NOME, g.LOCALITA, g.DATA
			");
    }
	
	function inserisci ($nome, $localita, $campionato, $dataGara) {
	
		include "funzioni_mysql.php";
		
		list($d, $m, $y) = explode('/', $dataGara);
		$mk=mktime(0, 0, 0, $m, $d, $y);
		$data=strftime('%Y-%m-%d',$mk);
		
		$t = "gara"; # nome della tabella
		$v = array ($nome,$localita,$campionato,$data,date("Y-m-d h:i:s"),date("Y-m-d h:i:s")); # valori da inserire
		$r =  "nome,localita,campionato,data,created,modified"; # campi da popolare
		
		$data = new MysqlClass();
		$data->connetti();
		$data->inserisci($t,$v,$r);
		$data->disconnetti();
	}

	function modifica ($idGara, $nome, $localita, $campionato, $dataGara) {
	
		include "funzioni_mysql.php";
		
		list($d, $m, $y) = explode('/', $dataGara);
		$mk=mktime(0, 0, 0, $m, $d, $y);
		$data=strftime('%Y-%m-%d',$mk);
		
		$tabella = "gara"; # nome della tabella
		$valori = array ($nome,$localita,$campionato,$data,date("Y-m-d h:i:s"),date("Y-m-d h:i:s")); # valori da inserire
		$campi =  array ('nome','localita','campionato','data','created','modified'); # campi da popolare
		
		$data = new MysqlClass();
		$data->connetti();
		$data->modifica($tabella,$valori,$campi,$idGara);
		$data->disconnetti();
	}
	
	function cancella ($idGara) {
		
		include "PresenzaManager.php";
		$PresenzaManager = new PresenzaManager();
		$listaPresenze = $PresenzaManager->listaGara($idGara);
		while ($listaPresenze_row = dbms_fetch_array($listaPresenze)) {
			return "-1";
		}
		
		$query = "delete from gara where ID = ".$idGara;
        return connetti_query($query);
	}
	
}
?>