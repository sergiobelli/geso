<?
 
//Parametri di accesso: mbasergio.altervista.org
//server, db, utente, passwd e prefisso per le tabelle 
$Host     = "sql.atleticavalsesia.it";
$Database = "atletica60358";
$User     = "atletica60358";
$Password = "atle17370";
$table_prefix = "sd";


//Parametri di accesso: www.freesql.org
//server, db, utente, passwd e prefisso per le tabelle 
/*$Host     = "www.freesql.org";
$Database = "geco";
$User     = "mbasergio";
$Password = "18ser07gio81";
$table_prefix = "sd";*/
?>
