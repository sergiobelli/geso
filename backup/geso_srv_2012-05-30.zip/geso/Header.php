<title>.: GESO - Gestione Societ&agrave; - Atletica Valsesia :.</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body class="FacetPageBODY">
<?require_once("adminnav.php");?>
<?require_once("copyleft.inc");?>
