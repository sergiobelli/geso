<title>.: GESO - Gestione Societ&agrave; - Atletica Valsesia :.</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body class="FacetPageBODY">

<br/>
<div align="center"><b>Gestione Societ&agrave; - Atletica Valsesia</b></div>
<br/>

<?require_once("adminnav.php");?>
<?require_once("copyleft.inc");?>	